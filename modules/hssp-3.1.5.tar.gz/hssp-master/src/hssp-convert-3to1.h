#ifndef HSSP_CONVERT_3TO1_H
#define HSSP_CONVERT_3TO1_H

#include <iostream>

void ConvertHsspFile(std::istream& in, std::ostream& out);

#endif // HSSP_CONVERT_3TO1_H
